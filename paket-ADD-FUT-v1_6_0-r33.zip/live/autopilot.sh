#!/usr/bin/env bash
# Автопилот бумажного этапа ADD-FUT: работает из системного cron, вне сессии Claude.
#
# УСТРОЙСТВО. Cron дёргает `tick` каждые 10 минут; тикер САМ считает время Чикаго
# (America/Chicago), поэтому переходы на зимнее/летнее время ничего не сдвигают. Торговая
# сессия — раз в день после 08:45 по бирже, замыкание — раз в день после 16:05; отметки
# «сделано за дату» лежат в ~/.addfut. Праздники биржи берутся из той же таблицы, что и
# ролл (daily.holidays_for): в праздник тикер не торгует.
#
# ДИСЦИПЛИНА ОТКАЗА — КАК У КОНТУРА. Любая ошибка торговли пишет файл-тревогу
# ~/.addfut/ALARM-*.txt, и автопилот БОЛЬШЕ НЕ ТОРГУЕТ, пока человек не удалит файл:
# автоматика не лечит расхождения руками. «Уже замкнута» при замыкании — штатный ответ.
#
# Секреты: логин/пароль шлюза — в ~/.addfut/ibgw.env (600), НЕ в репозитории.
# pipefail ОБЯЗАТЕЛЕН: без него код возврата принадлежал grep в конце конвейера, и НАСТОЯЩАЯ
# авария питона читалась как успех — тревога не сработала бы никогда. Найдено первым же
# пробным тиком.
set -u -o pipefail
ROOT=/home/alex/claude-projects/vol-down12
PY=$ROOT/.venv/bin/python
LIVE=$ROOT/r33build/live
ST=$HOME/.addfut
LOG=$ST/autopilot.log
ENVF=$ST/ibgw.env
ROUTE_F=$ST/route.txt            # маршрут пишет hand_over_book; нет файла — ТРЕВОГА (№1)

route() {
    # ПОТЕРЯ route.txt — НЕ ПОВОД ВЫБРАТЬ Ф (двадцать седьмой круг, №1). Молчаливый выбор
    # маршрута по умолчанию означал бы торговлю книгой, которая может быть неактивной:
    # после Ф→Е файл несёт E, и его исчезновение вернуло бы контур к фьючерсам поверх
    # фондовой позиции. Нет файла — тревога и остановка.
    if [ -s "$ROUTE_F" ]; then
        cat "$ROUTE_F"
    else
        alarm_write "$ST/ALARM-route-$(chicago %F).txt" \
            "нет $ROUTE_F — действующий маршрут неизвестен, торговля запрещена (О-5)" \
            2>/dev/null || true
        echo NONE
    fi
}

# ОКНА ПО МАРШРУТУ (десятый круг, №8): фонды маршрута Е торгуются в Европе (LSE/EBS,
# закрытие ~10:30 Чикаго). Торговать Е в 15:00 Чикаго значит вешать рыночные GTC на ночь
# чужой биржи; замыкание Е возможно уже после европейского закрытия.
trade_from()  { [ "$(route)" = E ] && echo 0845 || echo 0845; }
# КОНЕЦ ОКНА — ИЗ ОДНОГО ИСТОЧНИКА С КОНТУРОМ (двадцатый круг, №6): те же feed.TRADE_TILL,
# по которым сессия проверяет край перед КАЖДОЙ заявкой. Прежде значение жило только здесь,
# и разъехаться две копии могли молча. Считается один раз на тик (каждый тик — свой
# процесс); сбой вычисления — тревога и недостижимое время, то есть торговли не будет.
_TRADE_TILL_CACHE=""
trade_till() {
    if [ -z "$_TRADE_TILL_CACHE" ]; then
        local r t
        r=$(route)
        t=$(cd "$LIVE" && "$PY" -c "import sys,feed; sys.stdout.write(feed.trade_till('$r'))" 2>/dev/null)
        case "$t" in
            [0-9][0-9][0-9][0-9]) _TRADE_TILL_CACHE="$t";;
            *)  echo "конец торгового окна маршрута $r не вычислен (ответ: '$t')" \
                    > "$ST/ALARM-calendar-window.txt"
                (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-calendar-window.txt" \
                    >> "$ST/ALARM-calendar-window.txt" 2>&1) || true
                _TRADE_TILL_CACHE="0000";;   # окно считается закрытым: торговли не будет
        esac
    fi
    echo "$_TRADE_TILL_CACHE"
}
close_after() {
    # Маршрут Е: ворота ДИНАМИЧЕСКИЕ (семнадцатый круг, №5) — из того же feed.e_close_gate,
    # что у замыкателя; фиксированное 1040 в недели рассинхронизации DST давало отказ
    # «рано» и тревогу вместо ожидания. Сбой вычисления — тревога и недостижимое время.
    if [ "$(route)" = E ]; then
        local g
        g=$(cd "$LIVE" && "$PY" -c 'import feed; print(f"{feed.e_close_gate():%H%M}")' 2>/dev/null)
        case "$g" in
            [0-9][0-9][0-9][0-9]) echo "$g"; return;;
        esac
        echo "ворота Е не вычислены (ответ: '$g')" > "$ST/ALARM-calendar-e.txt"
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-calendar-e.txt" >> "$ST/ALARM-calendar-e.txt" 2>&1) || true
        echo 2359
    else
        echo 1605
    fi
}

# Свой замок В САМОМ СКРИПТЕ: строка crontab с flock — внешняя договорённость, её можно
# потерять при правке crontab; повторный вход должен быть невозможен независимо от неё.
# ОТКАЗ ОТКРЫТЬ ЗАМОК — ГРОМКИЙ (двадцатый круг, №12). Прежде здесь стояло `|| true`, и оно
# проглатывало ВСЁ: отсутствующий каталог состояния, права, read-only FS, ENOSPC. Дальше
# `flock -n 9` получал «Bad file descriptor», то есть НЕуспех, скрипт считал замок занятым
# и выходил с кодом 0 — а при отсутствующем сердцебиении даже без тревоги. Контур слеп
# ровно так же, как при декоративном cron (§12, семнадцатый круг): позиция стоит без
# торговли и без ролла вплоть до поставочной зоны.
if ! exec 9>"$ST/autopilot.lock" 2>/dev/null; then
    # Каталог состояния недоступен — тревожный файл писать НЕКУДА. Кричим в stderr (cron
    # доставляет его письмом) и выходим НЕнулевым кодом: молчаливый успех запрещён.
    echo "ADDFUT ТРЕВОГА: не открыть замок $ST/autopilot.lock — каталог состояния недоступен (нет каталога/прав/места); автопилот НЕ РАБОТАЕТ" >&2
    exit 3
fi
if ! flock -n 9; then
    # СТОРОЖ ЗАМКА (семнадцатый круг, №14): зависший владелец делал контур слепым — все
    # тики молча выходили, пропущенный ролл не замечал никто. Сердцебиение пишет владелец
    # в начале tick; его давность выше часа при занятом замке — тревога (пишется БЕЗ замка).
    hb="$ST/tick-heartbeat"
    if [ -f "$hb" ]; then
        age=$(( $(date +%s) - $(stat -c %Y "$hb" 2>/dev/null || echo 0) ))
        why="сердцебиение владельца устарело на ${age}с — процесс завис"
    else
        # СЕРДЦЕБИЕНИЯ НЕТ ВОВСЕ (двадцатый круг, №12): владелец либо не дошёл до его
        # записи, либо его не существует (замок держит чужой процесс, а fd открылся).
        # Один тик ничего не доказывает — гонка между flock и первой записью законна;
        # поэтому ставим метку и тревожим, если она переживёт час. Прежде эта ветка
        # молчала НАВСЕГДА: нет файла — нет проверки — нет тревоги.
        nohb="$ST/lock-nohb"
        [ -f "$nohb" ] || date +%s > "$nohb" 2>/dev/null || true
        age=$(( $(date +%s) - $(stat -c %Y "$nohb" 2>/dev/null || echo 0) ))
        why="сердцебиения нет вовсе ${age}с — владелец замка не наш или не дошёл до записи"
    fi
    if [ "$age" -gt 3600 ] && [ ! -e "$ST/ALARM-lock.txt" ]; then
        {
            echo "замок занят, $why"
            echo "владелец замка (fuser):"
            fuser -v "$ST/autopilot.lock" 2>&1 | tail -3
        } > "$ST/ALARM-lock.txt"
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-lock.txt" >> "$ST/ALARM-lock.txt" 2>&1) || true
        echo "$(date '+%F %T %Z') | ТРЕВОГА: замок автопилота завис (${age}с)" >> "$LOG"
    fi
    exit 0
fi
date +%s > "$ST/tick-heartbeat" 2>/dev/null || true
rm -f "$ST/lock-nohb" 2>/dev/null || true      # замок взят — метка «нет сердцебиения» снимается

# ПИН ТОРГОВОГО СЧЁТА В ОКРУЖЕНИЕ СЕССИИ (двадцатый круг, №5). Прежде ADDFUT_ACCOUNT не
# задавался НИГДЕ: ibgw.env несёт только логин и пароль, и грузился он вдобавок лишь на
# ветке подъёма шлюза — при уже работающем Gateway переменная не попадала в процесс сессии
# вовсе. Пин в адаптере был мёртв, а вместе с ним и проверка счёта у замера маржи.
# Отсутствие файла здесь НЕ тревожит: session.py откажет сам и с внятной причиной, а его
# отказ — нештатный, то есть уже даёт ALARM по общему правилу.
if [ -s "$ST/account.txt" ]; then
    ADDFUT_ACCOUNT=$(tr -d ' \t\n\r' < "$ST/account.txt"); export ADDFUT_ACCOUNT
fi

alarm_write() {
    # ЗАПИСЬ ТРЕВОГИ ОБЯЗАНА УДАТЬСЯ (двадцать четвёртый круг, №8). Прежде «echo > ALARM»
    # не проверялся и set -e нет: после ENOSPC, ACL «менять можно, создавать нельзя» или
    # ошибки каталога функция просто заканчивала тик. Следующий cron не видел ALARM и снова
    # входил в торговлю — дубль поверх неизвестного исхода. Не удалось записать файл —
    # пробуем запасное имя, затем syslog, и в любом случае возвращаем НЕуспех.
    local f=$1; shift
    if printf '%s\n' "$*" > "$f" 2>/dev/null && [ -s "$f" ]; then
        return 0
    fi
    local alt="${ST}/ALARM-fallback-$$.txt"
    if printf '%s\n' "$*" > "$alt" 2>/dev/null && [ -s "$alt" ]; then
        log "ТРЕВОГА записана в запасной файл $alt (основной $f недоступен)"
        return 0
    fi
    logger -t addfut "КРИТИЧНО: не удалось записать тревогу $f: $*" 2>/dev/null || true
    log "КРИТИЧНО: тревога НЕ записана ни в $f, ни в $alt — контур останавливается"
    return 1
}

log() { echo "$(date '+%F %T %Z') | $*" >> "$LOG"; }

chicago() { TZ=America/Chicago date "+$1"; }

env_guard() {
    # ЗАПРЕТ РАСПРОСТРАНЯЕТСЯ НА ВСЕ ADDFUT_* (двадцать третий круг, №22). Прежде
    # перечислялись четыре переменные, и мимо проходили: ADDFUT_REGISTRY (другой набор
    # conId), ADDFUT_SIGNALS_FALLBACK_OK (торговля по исследовательскому снимку),
    # ADDFUT_SIGNAL_CONFIRM (автоодобрение пограничных месяцев), ADDFUT_ASOF_OVERRIDE
    # (переход без часов и same-session), ADDFUT_MARGINS_CONST_OK, ADDFUT_LIVE_OK.
    # Каждая меняет целую позицию или снимает временные ворота — молча. Разрешены только
    # те, что автопилот ставит САМ; всё прочее — тревога до разбора.
    local _bad=""
    for _v in $(env | sed -n 's/^\(ADDFUT_[A-Z_]*\)=.*/\1/p'); do
        case "$_v" in
            ADDFUT_ACCOUNT) : ;;                     # ставит сам автопилот из account.txt
            *) _bad="$_bad $_v" ;;
        esac
    done
    if [ -n "$_bad" ]; then
        echo "посторонние переменные окружения:$_bad — торговля запрещена" \
            > "$ST/ALARM-env-$(chicago %F).txt"
        log "ТРЕВОГА: посторонние ADDFUT_*:$_bad"
        return 1
    fi
    # ОДИН NAMESPACE ПУТЕЙ (девятнадцатый круг, №17): автопилот работает ТОЛЬКО с машинным
    # каталогом ~/.addfut; переопределения ADDFUT_* — инструмент СТЕНДОВ. Тик с ними писал
    # бы тревоги и книгу туда, где автопилот их не ищет, — торговый вход при активных
    # переопределениях запрещается с тревогой (диагностика видна там, где её ищут).
    [ -z "${ADDFUT_DIR:-}${ADDFUT_LOCK_DIR:-}${ADDFUT_BOOK_PATH:-}${ADDFUT_SIGNALS:-}" ] && return 0
    if [ ! -e "$ST/ALARM-env.txt" ]; then
        {
            echo "автопилот запущен с переопределением ADDFUT_* — пути состояния раздвоены:"
            echo "  ADDFUT_DIR='${ADDFUT_DIR:-}' ADDFUT_LOCK_DIR='${ADDFUT_LOCK_DIR:-}'"
            echo "  ADDFUT_BOOK_PATH='${ADDFUT_BOOK_PATH:-}' ADDFUT_SIGNALS='${ADDFUT_SIGNALS:-}'"
        } > "$ST/ALARM-env.txt"
        log "ТРЕВОГА: переопределение ADDFUT_* в окружении автопилота — стоим"
    fi
    return 1
}

is_trade_day() {
    local dow; dow=$(chicago %u)                       # 6,7 — выходные
    [ "$dow" -ge 6 ] && return 1
    "$PY" - "$(route)" <<'PYEOF'
import sys
# ЛЮБАЯ НЕОЖИДАННАЯ ОШИБКА = КОД 2, А НЕ 1 (двадцать первый круг, №9). Код 1 означает
# «праздник/выходной», и Python отдаёт ровно его при ЛЮБОМ необработанном исключении:
# сломанный pandas, битый daily/feed, отсутствующий date — всё это заставляло тик молча
# уходить в ветку «сегодня не торгуем», без тревоги, до самой поставочной зоны. Импорты и
# создание Timestamp прежде стояли ВНЕ try, то есть именно они и давали ложный «праздник».
try:
    sys.path.insert(0, '/home/alex/claude-projects/vol-down12/r33build/live')
    sys.path.insert(0, '/home/alex/claude-projects/vol-down12/r33build')
    import pandas as pd, daily as DL, feed as FD, subprocess
    d = pd.Timestamp(subprocess.run(['date', '+%F'], env={'TZ': 'America/Chicago'},
                                    capture_output=True, text=True).stdout.strip())
    route = sys.argv[1] if len(sys.argv) > 1 else 'F'
    try:
        hol = (FD.eu_holidays(d.year) if route == 'E' else DL.holidays_for(d.year))
    except Exception:
        sys.exit(2)      # непокрытый год: НЕ «выходной», а тревога у вызывающего
    sys.exit(1 if d.normalize() in set(hol) else 0)
except SystemExit:
    raise
except BaseException:
    sys.exit(2)          # поломка среды тоже тревога, а не молчаливый «выходной»
PYEOF
}

ensure_gw() {
    if exec 3<>/dev/tcp/127.0.0.1/4002 2>/dev/null; then
        exec 3<&-
        # ПОРТ — ТОЛЬКО ПОВОД ПОЖАТЬ РУКУ (одиннадцатый круг, №7): полуживой шлюз с
        # открытым сокетом прежде допускался к торговле в обход заявленной проверки API.
        if "$PY" - <<'HS0'
import sys
sys.path.insert(0, '/home/alex/claude-projects/vol-down12/r33build/live')
import tz
from ib_insync import IB
ib = IB()
try:
    ib.connect('127.0.0.1', 4002, clientId=97, timeout=15)
    ok = bool(ib.managedAccounts())
    ib.disconnect()
    sys.exit(0 if ok else 1)
except Exception:
    sys.exit(1)
HS0
        then rm -f "$ST/gw-fails"; return 0; fi
    fi
    log "шлюз не отвечает — запускаю"
    [ -f "$ENVF" ] || { log "ТРЕВОГА: нет $ENVF — запускать шлюз нечем"; return 1; }
    # ОКРУЖЕНИЕ ШЛЮЗА НЕ ПОПАДАЕТ В ТОРГОВУЮ СЕССИЮ (двадцать четвёртый круг, №2).
    # `set -a; . ibgw.env` вносил ВСЁ содержимое файла в текущую оболочку — уже ПОСЛЕ
    # env_guard. Любые ADDFUT_REGISTRY, ADDFUT_SIGNALS_FALLBACK_OK, ADDFUT_LIVE_OK,
    # ADDFUT_ACCOUNT из него доставались сессии, и после обычного рестарта шлюза тот же
    # cron мог внезапно торговать другой счёт, другой con_id или исследовательский сигнал.
    # Переменные шлюза нужны ТОЛЬКО подпроцессу start.sh — читаем их в субоболочке.
    if grep -qE '^[[:space:]]*ADDFUT_' "$ENVF"; then
        alarm_write "$ST/ALARM-env-gw-$(chicago %F).txt" \
            "в $ENVF заданы ADDFUT_* — они попали бы в торговую сессию мимо env_guard" || true
        log "ТРЕВОГА: ADDFUT_* в $ENVF — запуск шлюза запрещён"
        return 1
    fi
    # fd 9 (замок) НЕ наследуется шлюзом (восемнадцатый круг, №9): долгоживущий Gateway
    # держал бы замок всё время жизни — все тики «занято», cron снова декоративный.
    # переменные шлюза живут только внутри субоболочки запуска (№2)
    ( exec 9>&-; set -a; . "$ENVF"; set +a; cd "$LIVE/ibgw" && nohup ./start.sh >> "$ST/ibgw-launch.log" 2>&1 & )
    for _ in $(seq 1 30); do
        sleep 10
        if exec 3<>/dev/tcp/127.0.0.1/4002 2>/dev/null; then exec 3<&-; break; fi
    done
    # ПОРТ — НЕ РУКОПОЖАТИЕ: сокет может слушать при мёртвом API. Пробуем подключиться.
    if "$PY" - <<'HS'
import sys
sys.path.insert(0, '/home/alex/claude-projects/vol-down12/r33build/live')
import tz
from ib_insync import IB
ib = IB()
try:
    ib.connect('127.0.0.1', 4002, clientId=96, timeout=20)
    ok = bool(ib.managedAccounts())
    ib.disconnect()
    sys.exit(0 if ok else 1)
except Exception:
    sys.exit(1)
HS
    then rm -f "$ST/gw-fails"; log "шлюз поднят, API отвечает"; return 0; fi
    n=$(( $(cat "$ST/gw-fails" 2>/dev/null || echo 0) + 1 )); echo "$n" > "$ST/gw-fails"
    log "шлюз/API не отвечает (подряд: $n)"
    if [ "$n" -ge 3 ]; then
        echo "шлюз или API мертвы три тика подряд" > "$ST/ALARM-gateway.txt"
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-gateway.txt" >> "$ST/ALARM-gateway.txt" 2>&1) || true
        log "ТРЕВОГА: шлюз мёртв три тика подряд — автопилот остановлен"
    fi
    return 1
}

run_trade() {
    local day=$1 out rc pre
    # ДАТА КНИГИ ДО ЗАПУСКА (девятнадцатый круг, №9): benign-ветка «день уже отторгован»
    # законна ТОЛЬКО если книга несла сегодняшнюю дату ещё ДО этого запуска. Книга,
    # записанная текущим (аварийным) запуском, — не штатный повтор: сессия успела сохранить
    # состояние и упала ПОСЛЕ (например, на пост-трейд проверке О-3-Е) — это тревога.
    pre=$(cd "$LIVE" && "$PY" - <<'BK0' 2>/dev/null
import sys
from pathlib import Path
import daily, state as ST
rt = Path.home() / '.addfut' / 'route.txt'
route = rt.read_text().strip() if rt.exists() else 'F'
cls = daily.BookE if route == 'E' else daily.Book
try:
    b, _, _ = ST.load(ST.book_path(route), cls)
except Exception:
    b = None
print((b.last_session or '') if b is not None else '')
BK0
    )
    # ВНЕШНИЙ ТАЙМАУТ ДОЛЖЕН БЫТЬ ДЛИННЕЕ ЗАКОННОГО ХУДШЕГО ВРЕМЕНИ (двадцать третий круг,
    # №20). Полный ролл упаковки ES+MES+ZN — до шести последовательных заявок, каждая
    # place() ждёт до 120 с плюс котировочный снимок: худший законный путь превышает 720 с,
    # а shell убивал процесс на 500-й — НЕ выполняя bail() ролла. Старая серия уже могла
    # быть закрыта, новая открыта частично, и оставались только намерение и тревога, без
    # автоматического восстановления. Берём 1200 с: вдвое больше законного худшего пути и
    # заведомо меньше окна сессии (08:45-15:30).
    out=$(cd "$LIVE" && timeout -k 60 1200 "$PY" session.py --live --route "$(route)" 2>&1 | grep -vE '^Error [0-9]+'); rc=$?
    echo "$out" >> "$LOG"
    if [ $rc -eq 0 ]; then
        touch "$ST/traded-$day"; log "торговля $day: ок"
    elif [ "$(cd "$LIVE" && "$PY" - "$day" <<'BK2' 2>/dev/null
import sys
from pathlib import Path
import daily, state as ST
rt = Path.home() / '.addfut' / 'route.txt'
route = rt.read_text().strip() if rt.exists() else 'F'
cls = daily.BookE if route == 'E' else daily.Book
b, _, _ = ST.load(ST.book_path(route), cls)
sys.stdout.write('1' if (b is not None and b.last_session == sys.argv[1]) else '0')
BK2
    )" = "1" ]; then
        # СОСТОЯНИЕ УЖЕ СОХРАНЕНО, А СЕССИЯ УПАЛА ПОСЛЕ (двадцать третий круг, №17): падение
        # clear_intent, пост-трейд margin_cushion или записи ALARM О-3-Е оставляло книгу у
        # брокера с сегодняшней датой, но БЕЗ traded-$day. Тревога разрешает замыкание
        # только по этому маркеру, ручной close требует его тоже — и кап закрытия не
        # фиксировался НИКОГДА. Маркер ставится по факту сохранённой книги; тревога при
        # этом всё равно поднимается ниже, торговля не продолжается.
        touch "$ST/traded-$day"
        alarm_write "$ST/ALARM-trade-$day.txt" "$out" || {
            # ОТКАЗ ЗАПИСИ ТРЕВОГИ — ОТКАЗ КОНТУРА (двадцать пятый круг, №11). Я сам
            # обесценил защиту припиской "|| true": файл не появлялся, тик заканчивался
            # нулём, следующий cron снова торговал поверх неизвестного исхода.
            log "КРИТИЧНО: тревога не записана — снимаю отметку дня, торговля запрещена"
            rm -f "$ST/traded-$day"
            return 1
        }
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-trade-$day.txt" >> "$ST/ALARM-trade-$day.txt" 2>&1) || true
        log "ТРЕВОГА торговли $day: состояние сохранено (книга за $day), сессия упала после — замыкание разрешено, торговля остановлена"
        return 1
    elif [ "$pre" = "$day" ] \
         && ! printf '%s' "$out" | grep -qE 'РАСХОЖДЕНИ|не совпада|разошлось с намерением|исход заявки неизвестен|НЕСНЯТ|открытые заявки|О-5|повреждён|ALARM|чужой счёт|не пинован|ЗА КРАЕМ' \
         && (cd "$LIVE" && "$PY" - "$day" <<'BK' >/dev/null 2>&1
import sys
from pathlib import Path
import daily, state as ST
rt = Path.home() / '.addfut' / 'route.txt'
route = rt.read_text().strip() if rt.exists() else 'F'
cls = daily.BookE if route == 'E' else daily.Book
b, _, _ = ST.load(ST.book_path(route), cls)   # load сверяет digest: порча файла = не штатно
sys.exit(0 if (b is not None and b.last_session == sys.argv[1]) else 1)
BK
    )
    then
        # ШТАТНОСТЬ — ПО КНИГЕ (пятнадцатый круг, №3): день считается отторгованным, если
        # книга несёт СЕГОДНЯШНЮЮ дату И несла её ДО запуска (девятнадцатый круг, №9: дату,
        # записанную самим аварийным запуском, повторной не считаем — только тревога).
        # Фразы и коды возврата хрупки: реальный повтор дал
        # rc=2 «не замкнута», а не ожидавшийся rc=1 «не новее».
        # ЕДИНСТВЕННЫЙ штатный отказ — «день уже отторгован». Первая попытка сужения не
        # применилась из-за несовпавшей строки, и это увидела ВНЕШНЯЯ рецензия, а не моя
        # проверка: правка без последующего grep — не правка. Любой другой ОТКАЗ (сигнал,
        # множитель, незамкнутость, посторонние позиции) — тревога.
        # ПРИЧИНА ОТКАЗА ЧИТАЕТСЯ (двадцать третий круг, №16). Прежде хватало «книга
        # несёт сегодняшнюю дату и несла её до запуска»: позднее исполнение, открытая
        # заявка, неверный счёт, повреждённый журнал или сбой котировок — всё, что
        # обнаружено ДО проверки «не новее», — выдавалось за штатный повтор, ALARM не
        # создавался, а книга уже могла расходиться с брокером. Признаки разрыва в выводе
        # сессии снимают «штатность»: остаётся обычная ветка тревоги.
        touch "$ST/traded-$day"; log "торговля $day: штатный отказ (день уже отторгован)"
    else
        alarm_write "$ST/ALARM-trade-$day.txt" "$out" || {
            # ОТКАЗ ЗАПИСИ ТРЕВОГИ — ОТКАЗ КОНТУРА (двадцать пятый круг, №11). Я сам
            # обесценил защиту припиской "|| true": файл не появлялся, тик заканчивался
            # нулём, следующий cron снова торговал поверх неизвестного исхода.
            log "КРИТИЧНО: тревога не записана — снимаю отметку дня, торговля запрещена"
            rm -f "$ST/traded-$day"
            return 1
        }
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-trade-$day.txt" >> "$ST/ALARM-trade-$day.txt" 2>&1) || true
        log "ТРЕВОГА торговли $day (код $rc) — автопилот остановлен до ручного разбора"
        return 1
    fi
}

run_close() {
    local day=$1 out rc
    out=$(cd "$LIVE" && timeout -k 30 400 "$PY" session.py --close --route "$(route)" 2>&1 | grep -vE '^Error [0-9]+'); rc=$?
    echo "$out" >> "$LOG"
    _closed_ok=0
    # ПРИЧИНА ОТКАЗА ЧИТАЕТСЯ И ЗДЕСЬ (двадцать четвёртый круг, №6): «книга уже замкнута»
    # объявляло успехом ЛЮБОЙ ненулевой код, включая поздний fill, расхождение с брокером
    # и открытую заявку — плечо закрытия оставалось посчитанным по ложной книге, ставился
    # closed-$day, тревоги не было.
    if [ $rc -ne 0 ] \
       && ! printf '%s' "$out" | grep -qE 'расходится с брокером|брокер изменился|РАСХОЖДЕНИ|О-5|поздни|неизвестен|НЕСНЯТ'; then
        (cd "$LIVE" && "$PY" - "$day" <<'BK2' >/dev/null 2>&1
import sys
from pathlib import Path
import daily, state as ST
rt = Path.home() / '.addfut' / 'route.txt'
route = rt.read_text().strip() if rt.exists() else 'F'
cls = daily.BookE if route == 'E' else daily.Book
b, _, _ = ST.load(ST.book_path(route), cls)   # digest + ДАТА: чужой день не «уже замкнут»
sys.exit(0 if (b is not None and b.last_session == sys.argv[1]
               and b.close_provisional is False) else 1)
BK2
        ) && _closed_ok=1
    fi
    if [ $rc -eq 0 ] || [ "$_closed_ok" = 1 ]; then
        touch "$ST/closed-$day"; log "замыкание $day: ок"
        backup_state "$day"
    else
        alarm_write "$ST/ALARM-close-$day.txt" "$out" || {
            log "КРИТИЧНО: тревога замыкания не записана — контур останавливается"
            return 1
        }
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-close-$day.txt" >> "$ST/ALARM-close-$day.txt" 2>&1) || true
        log "ТРЕВОГА замыкания $day (код $rc)"
        return 1
    fi
}

tick() {
    local day hm
    day=$(chicago %F); hm=$(chicago %H%M)
    # ТРЕВОГА ОСТАНАВЛИВАЕТ ТОРГОВЛЮ, НО НЕ ЗАМЫКАНИЕ ОТТОРГОВАННОГО ДНЯ (двадцать
    # второй круг, №7). Прежний полный стоп создавал тупик ровно на опасной книге: тревога
    # О-3-Е ставится ПОСЛЕ исполненных заявок, отметка traded уже стоит — и замыкание
    # запрещалось той же строкой; назавтра do_close отказывал по чужой дате книги, и книга
    # с низким запасом застревала close_provisional НАВСЕГДА, а обещанное сокращение
    # следующей сессией не могло даже начаться (для него нужен триггер капа замыкания).
    # Замыкание НЕ подаёт заявок — это запись фактических цен и NLV, то есть наблюдение;
    # О-5 не нарушается: лечить по-прежнему нечем и некому.
    if ls "$ST"/ALARM-*.txt >/dev/null 2>&1; then
        local _d0
        _d0=$(chicago %F)
        if [ -e "$ST/traded-$_d0" ] && [ ! -e "$ST/closed-$_d0" ] \
           && [ "$(chicago %H%M)" -ge "$(close_after)" ]; then
            log "тревога стоит, но день $_d0 отторгован и не замкнут — выполняю ТОЛЬКО замыкание"
            ensure_gw && run_close "$_d0"
        fi
        return 0                                         # торговли под тревогой нет
    fi
    # ГОРИЗОНТ КАЛЕНДАРЯ (двадцать первый круг, №12): таблицы праздников продлеваются
    # вручную, и обрыв обнаруживался в тот день, когда торговать уже нельзя — у маршрута Е
    # таблица кончается 2026 годом. Это ПРЕДУПРЕЖДЕНИЕ, а не тревога: ALARM-* останавливает
    # контур целиком, а за три месяца до обрыва останавливать нечего. Раз в день.
    local _wd="$ST/WARN-calendar-horizon-$(chicago %Y-%m).txt"
    if [ ! -e "$_wd" ]; then
        local _h
        _h=$(cd "$LIVE" && "$PY" -c "
import sys, feed
ok, msg = feed.calendar_horizon('$(route)')
sys.stdout.write(('OK ' if ok else 'NO ') + msg)" 2>&1)
        case "$_h" in
            OK\ *) : ;;
            *) echo "$_h" > "$_wd"; log "ВНИМАНИЕ: $_h" ;;
        esac
    fi
    # ГОРИЗОНТ РЕЕСТРА (двадцать второй круг, №12): реестр пишет только first_connect, и
    # без предупреждения ноябрьский ролл встал бы В ДЕНЬ ролла без ориентиров H27, оставив
    # Z26 у декабрьской поставки. Раз в день; ПРЕДУПРЕЖДЕНИЕ, не ALARM — оператору нужно
    # утро, чтобы запустить first_connect, останавливать торговлю не за чем.
    local _wr="$ST/WARN-registry-$(chicago %F).txt"
    if [ ! -e "$_wr" ]; then
        local _rh
        _rh=$(cd "$LIVE" && "$PY" -c "
import sys, feed, state, daily
sys.path.insert(0, '.')
try:
    bk, _, rt = state.load(state.book_path('$(route)'),
                           daily.BookE if '$(route)' == 'E' else daily.Book)
    ok, msg = (True, 'книги нет') if bk is None else feed.registry_horizon(bk)
    sys.stdout.write(('OK ' if ok else 'NO ') + msg)
except Exception as ex:
    sys.stdout.write('NO проверка горизонта реестра сломана: %r' % (ex,))" 2>&1)
        case "$_rh" in
            OK\ *) : ;;
            *) echo "$_rh" > "$_wr"; log "ВНИМАНИЕ: $_rh" ;;
        esac
    fi
    if [ "$(route)" = NONE ]; then
        log "ТРЕВОГА: действующий маршрут неизвестен — торговля и замыкание запрещены"
        return 0
    fi
    is_trade_day; _td=$?
    if [ "$_td" -eq 2 ]; then
        echo "календарь маршрута $(route) не покрывает текущий год" > "$ST/ALARM-calendar.txt"
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-calendar.txt" >> "$ST/ALARM-calendar.txt" 2>&1) || true
        log "ТРЕВОГА: календарь не покрыт — автопилот остановлен"
        return 0
    fi
    case "$_td" in
        0) : ;;                             # торговый день
        1)  # ОДНОСТОРОННИЙ ЕВРОПЕЙСКИЙ ПРАЗДНИК НЕ ВЫКЛЮЧАЕТ ВАХТУ О-3-Е (двадцать
            # шестой круг, №10). HOLIDAYS_EU — ОБЪЕДИНЕНИЕ закрытий LSE и SIX: 1 и 4 мая
            # 2026 одна площадка работает, стоимость маржинальной книги и MaintMarginReq
            # меняются, а тик возвращался ДО внутридневной вахты — запас мог уйти ниже
            # 1,40 без единого замера. Торговли в такой день нет (общего окна нет), но
            # НАБЛЮДЕНИЕ за запасом обязано идти: это не заявка, а измерение.
            if [ "$(route)" = E ] && [ ! -e "$ST/ALARM-o3e-blind-$day.txt" ]; then
                _cw=$(cd "$LIVE" && timeout -k 10 90 "$PY" -c "
import sys
sys.path.insert(0, '.')
from ib_insync import IB
import ib_broker as IBB, daily as DL
ib = IB()
try:
    ib.connect('127.0.0.1', 4002, clientId=95, timeout=15)
    c = IBB.IBBroker(ib).margin_cushion()
    ib.disconnect()
except Exception as ex:
    sys.stdout.write('SKIP %r' % (ex,)); raise SystemExit
sys.stdout.write(('LOW %.3f' % c) if (c is not None and c < DL.O3E_MIN)
                 else ('OK %.3f' % c if c is not None else 'SKIP запаса нет'))" 2>&1)
                case "$_cw" in
                    LOW\ *)
                        alarm_write "$ST/ALARM-o3e-holiday-$day.txt" \
                            "в НЕторговый день запас О-3-Е упал: $_cw (порог 1.40) — О-5" \
                            || log "КРИТИЧНО: тревога О-3-Е праздничного дня не записана"
                        log "ТРЕВОГА: запас О-3-Е ниже порога в неторговый день ($_cw)" ;;
                    *) : ;;
                esac
            fi
            return 0 ;;                     # выходной/праздник — торговли нет (девятнадцатый
                                            # круг, №7: суббота — не поломка календаря)
        2)  # непокрытый год таблиц — тревога, как и заявлял python-подпроцесс
            if [ ! -e "$ST/ALARM-calendar.txt" ]; then
                echo "календарь маршрута $(route) не покрывает текущий год" > "$ST/ALARM-calendar.txt"
                (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-calendar.txt" >> "$ST/ALARM-calendar.txt" 2>&1) || true
                log "ТРЕВОГА: календарь не покрывает год"
            fi
            return 0 ;;
        *)  # поломка календарного подпроцесса (восемнадцатый круг, №10): молчаливый
            # «выходной» прятал бы мёртвый контур неделями — только тревога.
            if [ ! -e "$ST/ALARM-calendar-broken.txt" ]; then
                echo "календарный подпроцесс вернул код $_td — контур не может определить торговый день" > "$ST/ALARM-calendar-broken.txt"
                (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-calendar-broken.txt" >> "$ST/ALARM-calendar-broken.txt" 2>&1) || true
                log "ТРЕВОГА: календарь сломан (код $_td)"
            fi
            return 0 ;;
    esac
    if [ "$hm" -ge "$(trade_till)" ] && [ ! -e "$ST/traded-$day" ] && [ ! -e "$ST/ALARM-missed-$day.txt" ]; then
        # ДЕНЬ ПРОПУЩЕН: все тики до конца окна потеряны (машина спала). Торговать в 16:05
        # и тут же замыкать — значит оставить рыночные GTC на ночь; вместо этого тревога.
        echo "тики торгового окна $day пропущены (первый после $hm)" > "$ST/ALARM-missed-$day.txt"
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-missed-$day.txt" >> "$ST/ALARM-missed-$day.txt" 2>&1) || true
        log "ТРЕВОГА: торговое окно $day пропущено — сессии не будет"
        return 0
    fi
    if [ "$hm" -ge "$(trade_from)" ] && [ "$hm" -lt "$(trade_till)" ] && [ ! -e "$ST/traded-$day" ]; then
        ensure_gw || return 0
        # МЕСЯЧНЫЙ СИГНАЛ ПЕРЕД ПЕРВОЙ ТОРГОВЛЕЙ МЕСЯЦА: строка месяца действия обязана
        # существовать до сделки; сбой обновления — тревога, торговли нет.
        local mon; mon=$(chicago %Y-%m)
        if [ ! -e "$ST/sigup-$mon" ]; then
            local sout
            if sout=$(cd "$LIVE" && timeout -k 30 300 "$PY" signal_update.py 2>&1 | grep -vE '^Error [0-9]+'); then
                echo "$sout" >> "$LOG"; touch "$ST/sigup-$mon"; log "сигнал $mon: обновлён/сверен"
            else
                echo "$sout" > "$ST/ALARM-signal-$mon.txt"
                (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-signal-$mon.txt" >> "$ST/ALARM-signal-$mon.txt" 2>&1) || true
                log "ТРЕВОГА сигнала $mon — торговли не будет до ручного разбора"
                return 0
            fi
        fi
        # ОКНО ПЕРЕПРОВЕРЯЕТСЯ ПОСЛЕ ПОДГОТОВКИ (семнадцатый круг, №13): подъём шлюза и
        # месячный сигнал занимают минуты — заявка, поданная за краем окна, висела бы GTC
        # до чужой сессии. Пропущенное окно поймает штатный механизм ALARM-missed.
        hm=$(chicago %H%M)
        if [ "$hm" -ge "$(trade_till)" ]; then
            log "окно ушло за время подготовки (сейчас $hm) — торговля не начинается"
        else
            run_trade "$day"
        fi
    fi
    # ВАХТА О-3-Е МЕЖДУ ТОРГОВЛЕЙ И ЗАМЫКАНИЕМ (двадцать второй круг, №6): прежде запас
    # наблюдался ровно один раз — при заявках; после traded-* тики его не смотрели, и
    # провал ниже 1,40 позже в сессии (или на дне без ребаланса) не давал ни тревоги, ни
    # сокращения. Только маршрут Е (О-3-Е — его ворота), только пока день не замкнут.
    # Тревога = стоп и ручной разбор: автоматика по-прежнему ничего не сокращает сама.
    if [ "$(route)" = E ] && [ -e "$ST/traded-$day" ] && [ ! -e "$ST/closed-$day" ] \
       && [ ! -e "$ST/ALARM-o3e-blind-$day.txt" ]; then
        local _cw
        _cw=$(cd "$LIVE" && timeout -k 10 90 "$PY" -c "
import sys
sys.path.insert(0, '.')
import tz
from ib_insync import IB
import ib_broker as IBB
import daily as DL
ib = IB()
try:
    ib.connect('127.0.0.1', 4002, clientId=94, timeout=15)
    c = IBB.IBBroker(ib).margin_cushion()
    ib.disconnect()
except Exception as ex:
    sys.stdout.write('SKIP %r' % (ex,)); raise SystemExit
if c is None:
    sys.stdout.write('SKIP запаса нет (пустая книга или неполная сводка)')
elif c < DL.O3E_MIN:
    sys.stdout.write('LOW %.3f' % c)
else:
    sys.stdout.write('OK %.3f' % c)" 2>&1)
        case "$_cw" in
            LOW\ *)
                alarm_write "$ST/ALARM-o3e-intraday-$day.txt" "внутридневной запас О-3-Е упал: $_cw (порог 1.40) — О-5" \
                    || log "КРИТИЧНО: тревога О-3-Е не записана"
                (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-o3e-intraday-$day.txt" >> "$ST/ALARM-o3e-intraday-$day.txt" 2>&1) || true
                log "ТРЕВОГА: внутридневной запас О-3-Е ($_cw) ниже порога — автопилот остановлен" ;;
            OK\ *) rm -f "$ST/o3e-watch-fail-$day" ;;   # успех обнуляет счётчик подряд
            *) # сбой замера не тревожит каждый тик — раз в день пометка в лог
               _wf="$ST/o3e-watch-fail-$day"
               _n=$(( $( [ -s "$_wf" ] && cat "$_wf" || echo 0 ) + 1 ))
               echo "$_n" > "$_wf"
               log "вахта О-3-Е: замер не удался ($_cw), подряд $_n"
               if [ "$_n" -ge 3 ]; then
                   alarm_write "$ST/ALARM-o3e-blind-$day.txt" "запас О-3-Е не измеряется $_n тика подряд: $_cw — О-5" \
                       || log "КРИТИЧНО: тревога слепой вахты не записана"
                   log "ТРЕВОГА: вахта О-3-Е ослепла на $_n тика подряд"
               fi ;;
        esac
    fi
    if [ "$hm" -ge "$(close_after)" ] && [ -e "$ST/traded-$day" ] && [ ! -e "$ST/closed-$day" ]; then
        ensure_gw && run_close "$day"
    fi
    find "$ST" -maxdepth 1 -name 'traded-*' -mtime +14 -delete 2>/dev/null
    find "$ST" -maxdepth 1 -name 'closed-*' -mtime +14 -delete 2>/dev/null
    # АРХИВ НАМЕРЕНИЙ (двадцатый круг, №16): снятое намерение не удаляется, а
    # переименовывается — оно единственное говорит, что НАМЕЧАЛОСЬ. Хранится две недели,
    # как отметки торговли: дольше оно не нужно, а расти без предела не должно.
    # МАСКА ПО РЕАЛЬНОМУ ИМЕНИ (двадцать первый круг, №17): файл называется
    # book-F.json.intent-done-<ts>.json, и прежняя маска 'intent-*-done-*' не совпадала
    # с ним НИКОГДА — уборка была декоративной, архив рос без предела.
    find "$ST" -maxdepth 1 -name '*intent-done-*' -mtime +14 -delete 2>/dev/null
}

backup_state() {
    # РЕЗЕРВНАЯ КОПИЯ МАШИННОГО СОСТОЯНИЯ после каждого замыкания: книга, журнал §7, живой
    # ряд сигналов и уровни. СЕКРЕТЫ (ibgw.env) НЕ КОПИРУЮТСЯ. Храним 30 последних.
    # УНИКАЛЬНОЕ ИМЯ И АТОМАРНАЯ ПУБЛИКАЦИЯ (тринадцатый круг, №10): повторное событие
    # той же даты (замыкание после перехода) не затирает предыдущий снимок, падение tar не
    # оставляет усечённый архив под рабочим именем.
    local day=$1 bdir=$HOME/.addfut-backups stamp
    stamp=$(date -u +%H%M%S)
    mkdir -p "$bdir"
    # СОГЛАСОВАННЫЙ СНИМОК ПОД ЗАМКОМ КНИГИ (восемнадцатый круг, №19) + WORM-якорь того же
    # поколения (№18: state.load, действующие пути, атомарная запись, git с проверкой).
    if wa=$(cd "$LIVE" && "$PY" worm_anchor.py --snap "$day" "$bdir" 2>&1); then
        log "снимок+WORM: $wa"
        # ВНЕШНЯЯ ВЫГРУЗКА ПОД ПРОВЕРКОЙ (пятнадцатый круг, №7): разовый сбой сети — не
        # тревога (локальная копия есть, догонит следующим замыканием), но три подряд
        # означают, что внешних копий давно нет, — стоим до ручного разбора.
        if timeout -k 30 180 /bin/bash /home/alex/claude-projects/vol-down12/tools/backup_push.sh >>"$LOG" 2>&1; then
            rm -f "$ST/push-fails"
        else
            local pf=0
            [ -f "$ST/push-fails" ] && pf=$(cat "$ST/push-fails")
            pf=$((pf + 1)); echo "$pf" > "$ST/push-fails"
            log "внешняя выгрузка копий не удалась ($pf подряд)"
            if [ "$pf" -ge 3 ]; then
                echo "backup_push.sh не удаётся $pf замыканий подряд — внешних копий нет" > "$ST/ALARM-push.txt"
                (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-push.txt" >> "$ST/ALARM-push.txt" 2>&1) || true
                log "ТРЕВОГА: внешние копии не выгружаются — автопилот остановлен"
                return 1
            fi
        fi
    else
        echo "снимок состояния/WORM за $day не создан: $wa" > "$ST/ALARM-backup-$day.txt"
        (cd "$LIVE" && "$PY" diagnose.py "$ST/ALARM-backup-$day.txt" >> "$ST/ALARM-backup-$day.txt" 2>&1) || true
        log "ТРЕВОГА: резервная копия $day не создана — автопилот остановлен"
        return 1
    fi
    ls -1t "$bdir"/addfut-*.tgz 2>/dev/null | tail -n +61 | xargs -r rm -f
}

status() {
    local day; day=$(chicago %F)
    echo "Чикаго: $(chicago '%F %H:%M %Z'); торговый день: $(is_trade_day && echo да || echo нет)"
    echo "сегодня: торговля $( [ -e "$ST/traded-$day" ] && echo сделана || echo нет ), \
замыкание $( [ -e "$ST/closed-$day" ] && echo сделано || echo нет )"
    ls "$ST"/ALARM-*.txt 2>/dev/null && echo "^^^ ТРЕВОГА: автопилот стоит" || echo "тревог нет"
    tail -5 "$LOG" 2>/dev/null
}

guard_manual() {
    # РУЧНОЙ ВХОД ПРОХОДИТ ТЕ ЖЕ ВОРОТА (четырнадцатый круг, №10): вызов trade в 15:00 по
    # маршруту Е отправил бы GTC на закрытую Европу, а без sigup — торговлю без сигнала.
    ls "$ST"/ALARM-*.txt >/dev/null 2>&1 && { echo "стоит ТРЕВОГА — сначала разбор"; return 1; }
    is_trade_day; [ $? -eq 0 ] || { echo "не торговый день маршрута $(route)"; return 1; }
    return 0
}

case "${1:-tick}" in
    tick)   env_guard && tick ;;
    trade)
        env_guard || exit 1
        guard_manual || exit 1
        hm=$(chicago %H%M); day=$(chicago %F)
        { [ "$hm" -ge "$(trade_from)" ] && [ "$hm" -lt "$(trade_till)" ]; } \
            || { echo "вне торгового окна маршрута $(route)"; exit 1; }
        mon=$(chicago %Y-%m)
        [ -e "$ST/sigup-$mon" ] || { echo "сигнал месяца не обновлён (sigup-$mon)"; exit 1; }
        ensure_gw && run_trade "$day" ;;
    close)
        env_guard || exit 1
        # ЗАМЫКАНИЕ ОТТОРГОВАННОГО ДНЯ РАЗРЕШЕНО И ПОД ТРЕВОГОЙ (двадцать второй круг,
        # №7): guard_manual запрещал close после тревоги О-3-Е, и книга с исполненными
        # заявками не могла зафиксировать триггер капа — тупик на самой опасной книге.
        # Замыкание заявок не подаёт; торговый вход по-прежнему под полным guard_manual.
        day=$(chicago %F)
        if ls "$ST"/ALARM-*.txt >/dev/null 2>&1; then
            if [ -e "$ST/traded-$day" ] && [ ! -e "$ST/closed-$day" ]; then
                echo "тревога стоит, но день $day отторгован и не замкнут — замыкаю (только запись цен/NLV)"
            else
                echo "стоит ТРЕВОГА — сначала разбор"; exit 1
            fi
        else
            guard_manual || exit 1
        fi
        hm=$(chicago %H%M)
        [ "$hm" -ge "$(close_after)" ] || { echo "до окна замыкания маршрута $(route)"; exit 1; }
        ensure_gw && run_close "$day" ;;
    diagnose)
        found=0
        for f in "$ST"/ALARM-*.txt; do
            [ -e "$f" ] || continue
            found=1
            echo "=== $f ==="
            (cd "$LIVE" && "$PY" diagnose.py "$f") || true
        done
        [ "$found" = 1 ] || echo "тревог нет"
        ;;
    status) status ;;
    *) echo "команды: tick|trade|close|status"; exit 1 ;;
esac
